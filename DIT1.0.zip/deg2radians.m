function rad=deg2radians(degree)
% Transforms degree to radians
    rad=degree.*pi/180;
end